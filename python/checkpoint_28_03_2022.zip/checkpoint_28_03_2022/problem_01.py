print("Nome: César Javier Noreña Pachón")
print("RM: 95093")
